
package circuitry_and_magic.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class ArcaneRecieverOnBlock extends Block {
	public static final DirectionProperty FACING = DirectionalBlock.FACING;

	public ArcaneRecieverOnBlock() {
		super(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).sound(SoundType.METAL).strength(3f, 5f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(5, 0, 0, 11, 8, 5), box(5, 8, 0, 6, 12, 1), box(4.915, 10.935, -0.085, 6.065, 12.085, 1.065));
			case NORTH -> Shapes.or(box(5, 0, 11, 11, 8, 16), box(10, 8, 15, 11, 12, 16), box(9.935, 10.935, 14.935, 11.085, 12.085, 16.085));
			case EAST -> Shapes.or(box(0, 0, 5, 5, 8, 11), box(0, 8, 10, 1, 12, 11), box(-0.085, 10.935, 9.935, 1.065, 12.085, 11.085));
			case WEST -> Shapes.or(box(11, 0, 5, 16, 8, 11), box(15, 8, 5, 16, 12, 6), box(14.935, 10.935, 4.915, 16.085, 12.085, 6.065));
			case UP -> Shapes.or(box(5, 0, 0, 11, 5, 8), box(10, 0, 8, 11, 1, 12), box(9.935, -0.085, 10.935, 11.085, 1.065, 12.085));
			case DOWN -> Shapes.or(box(5, 11, 8, 11, 16, 16), box(10, 15, 4, 11, 16, 8), box(9.935, 14.935, 3.915, 11.085, 16.085, 5.065));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(FACING, context.getClickedFace());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public float getEnchantPowerBonus(BlockState state, LevelReader world, BlockPos pos) {
		return 5f;
	}

	@Override
	public boolean isSignalSource(BlockState state) {
		return true;
	}

	@Override
	public int getSignal(BlockState blockstate, BlockGetter blockAccess, BlockPos pos, Direction direction) {
		return 15;
	}

	@Override
	public boolean canConnectRedstone(BlockState state, BlockGetter world, BlockPos pos, Direction side) {
		return true;
	}
}
