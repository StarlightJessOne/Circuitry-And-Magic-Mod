
package circuitry_and_magic.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class ArcanaDustItem extends Item {
	public ArcanaDustItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
