
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package circuitry_and_magic.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import circuitry_and_magic.item.ArcaneTransmitterItem;
import circuitry_and_magic.item.ArcanaDustItem;

import circuitry_and_magic.CircuitryAndMagicMod;

public class CircuitryAndMagicModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(CircuitryAndMagicMod.MODID);
	public static final DeferredItem<Item> ARCANE_TRANSMITTER = REGISTRY.register("arcane_transmitter", ArcaneTransmitterItem::new);
	public static final DeferredItem<Item> ARCANA_DUST = REGISTRY.register("arcana_dust", ArcanaDustItem::new);
	public static final DeferredItem<Item> ARCANE_TRANSMITTER_BLOCK = block(CircuitryAndMagicModBlocks.ARCANE_TRANSMITTER_BLOCK);
	public static final DeferredItem<Item> ARCANA_BLOCK = block(CircuitryAndMagicModBlocks.ARCANA_BLOCK);
	public static final DeferredItem<Item> ARCANE_RECIEVER_OFF = block(CircuitryAndMagicModBlocks.ARCANE_RECIEVER_OFF);
	public static final DeferredItem<Item> ARCANE_RECIEVER_ON = block(CircuitryAndMagicModBlocks.ARCANE_RECIEVER_ON);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
