
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package circuitry_and_magic.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import circuitry_and_magic.block.ArcaneTransmitterBlockBlock;
import circuitry_and_magic.block.ArcaneRecieverOnBlock;
import circuitry_and_magic.block.ArcaneRecieverOffBlock;
import circuitry_and_magic.block.ArcanaBlockBlock;

import circuitry_and_magic.CircuitryAndMagicMod;

public class CircuitryAndMagicModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(CircuitryAndMagicMod.MODID);
	public static final DeferredBlock<Block> ARCANE_TRANSMITTER_BLOCK = REGISTRY.register("arcane_transmitter_block", ArcaneTransmitterBlockBlock::new);
	public static final DeferredBlock<Block> ARCANA_BLOCK = REGISTRY.register("arcana_block", ArcanaBlockBlock::new);
	public static final DeferredBlock<Block> ARCANE_RECIEVER_OFF = REGISTRY.register("arcane_reciever_off", ArcaneRecieverOffBlock::new);
	public static final DeferredBlock<Block> ARCANE_RECIEVER_ON = REGISTRY.register("arcane_reciever_on", ArcaneRecieverOnBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
