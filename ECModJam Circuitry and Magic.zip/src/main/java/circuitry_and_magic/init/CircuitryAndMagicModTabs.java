
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package circuitry_and_magic.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import circuitry_and_magic.CircuitryAndMagicMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class CircuitryAndMagicModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CircuitryAndMagicMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(CircuitryAndMagicModItems.ARCANE_TRANSMITTER.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(CircuitryAndMagicModBlocks.ARCANE_TRANSMITTER_BLOCK.get().asItem());
			tabData.accept(CircuitryAndMagicModBlocks.ARCANA_BLOCK.get().asItem());
			tabData.accept(CircuitryAndMagicModBlocks.ARCANE_RECIEVER_OFF.get().asItem());
		}
	}
}
